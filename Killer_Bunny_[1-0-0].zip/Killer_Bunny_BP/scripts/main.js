import {world} from "@minecraft/server";
import * as data from "index";