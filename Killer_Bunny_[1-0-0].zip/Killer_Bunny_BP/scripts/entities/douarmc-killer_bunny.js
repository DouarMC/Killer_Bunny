import { world } from "@minecraft/server";
world.afterEvents.entitySpawn.subscribe((eventData) => {
    const entity = eventData.entity;
    if (entity.typeId === "douarmc_kb:killer_bunny") {
        entity.nameTag = "The Killer Bunny";
    }
    ;
});
